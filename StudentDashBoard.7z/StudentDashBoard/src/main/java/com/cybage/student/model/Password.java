package com.cybage.student.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name="password")
public class Password {

	@Id
	@GeneratedValue
	@Column(name="p_id")
	private int p_id;
	
	@Column(name="s_pass")
	private String s_pass;

	
	
	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getS_pass() {
		return s_pass;
	}

	public void setS_pass(String s_pass) {
		this.s_pass = s_pass;
	}

	
}
