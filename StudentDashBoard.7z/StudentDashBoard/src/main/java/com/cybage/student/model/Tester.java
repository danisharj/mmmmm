package com.cybage.student.model;

import org.hibernate.Session;

import com.cybage.student.config.HibernateSessionManager;

public class Tester {
	
	public static void main(String args[]){
		
		Password sp=new Password();
		sp.setS_pass("12345");
		Student st=new Student();
		st.setS_name("abc");
		st.setS_email("a@b.c");
		st.setPh_num("12345");
		//st.setS_pass(sp);
		
		
		
		Session session = HibernateSessionManager.getSessionFactory().openSession();
		 
		 session.beginTransaction();
		 session.save(st);
		 session.getTransaction().commit();
	}

}
