package com.cybage.student.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studentpassword")
public class StudentPassword {
	
	@Id
	@GeneratedValue
	@Column(name="p_id")
	private int p_pd;
	
	public int getP_pd() {
		return p_pd;
	}

	public void setP_pd(int p_pd) {
		this.p_pd = p_pd;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name="password")
	private String password;

}
