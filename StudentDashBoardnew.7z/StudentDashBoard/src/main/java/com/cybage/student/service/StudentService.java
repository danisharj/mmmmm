package com.cybage.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cybage.student.dao.StudentDao;
import com.cybage.student.model.Student;
import com.cybage.student.model.StudentMarks;

@Service
@Component
public class StudentService {
	
	//@Autowired
	StudentDao studentDao=new StudentDao();
	public void registerStudent(Student student){
		
		studentDao.save(student);
		
	}
	
	public Student aunthenticate(String un,String pw){
		
		Student st=studentDao.checkauthentic(un, pw);
		
		
		return st;
	}
	
	public StudentMarks saveMarks( int id,String sem1,String sem2,String sem3,String sem4,String sem5,String sem6,String sem7,String sem8)
	{
		StudentMarks sm=studentDao.saveMarks(id,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8);
		return sm;
	}
	 
	public StudentMarks getMarks(int id)
	{
		StudentMarks list=studentDao.getMarks(id);
		return list;
	}
	

}
