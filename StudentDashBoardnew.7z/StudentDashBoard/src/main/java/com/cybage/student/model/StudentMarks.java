package com.cybage.student.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studentmarksnew")
public class StudentMarks {
	
	@Id
	@Column(name="st_id")
	private int st_id;
	
	@Column(name="1st_sem")
	private String sem1;
	
	@Column(name="2nd_sem")
	private String sem2;
	
	@Column(name="3rd_sem")
	private String sem3;
	
	@Column(name="4th_sem")
	private String sem4;
	
	@Column(name="5th_sem")
	private String sem5;
	
	@Column(name="6th_sem")
	private String sem6;
	
	@Column(name="7th_sem")
	private String sem7;
	
	@Column(name="8th_sem")
	private String sem8;

	public int getSt_id() {
		return st_id;
	}

	public void setSt_id(int st_id) {
		this.st_id = st_id;
	}

	public String getSem1() {
		return sem1;
	}

	public void setSem1(String sem1) {
		this.sem1 = sem1;
	}

	public String getSem2() {
		return sem2;
	}

	public void setSem2(String sem2) {
		this.sem2 = sem2;
	}

	public String getSem3() {
		return sem3;
	}

	public void setSem3(String sem3) {
		this.sem3 = sem3;
	}

	public String getSem4() {
		return sem4;
	}

	public void setSem4(String sem4) {
		this.sem4 = sem4;
	}

	public String getSem5() {
		return sem5;
	}

	public void setSem5(String sem5) {
		this.sem5 = sem5;
	}

	public String getSem6() {
		return sem6;
	}

	public void setSem6(String sem6) {
		this.sem6 = sem6;
	}

	public String getSem7() {
		return sem7;
	}

	public void setSem7(String sem7) {
		this.sem7 = sem7;
	}

	public String getSem8() {
		return sem8;
	}

	public void setSem8(String sem8) {
		this.sem8 = sem8;
	}

	
	

}
