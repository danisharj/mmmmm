package com.cybage.student.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnTransformer;
import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.jasypt.hibernate.type.EncryptedStringType;




@Entity
@Table(name="Student")
public class Student {
	
	@Id
	@GeneratedValue
	@Column(name="s_id")
	private int s_id;
	
	@Column(name="s_name")
	private String s_name;
	
	@Column(name="s_email")
	private String s_email;
	
    @Column(name="ph_num")
    private String ph_num;
    
    @Column(name="pass")
    
    private String s_pass;
    
    
    


	
	public int getS_id() {
		return s_id;
	}


	

	
	public String getS_pass() {
		return s_pass;
	}





	public void setS_pass(String s_pass) {
		this.s_pass = s_pass;
	}





	public void setS_id(int s_id) {
		this.s_id = s_id;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getS_email() {
		return s_email;
	}

	public void setS_email(String s_email) {
		this.s_email = s_email;
	}

	public String getPh_num() {
		return ph_num;
	}

	public void setPh_num(String ph_num) {
		this.ph_num = ph_num;
	}





	@Override
	public String toString() {
		return "Student [s_email=" + s_email + ", s_pass=" + s_pass + "]";
	}





    
    
    

}
