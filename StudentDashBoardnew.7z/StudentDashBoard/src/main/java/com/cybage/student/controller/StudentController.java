package com.cybage.student.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.student.model.Password;
import com.cybage.student.model.Student;
import com.cybage.student.model.StudentMarks;
import com.cybage.student.service.StudentService;




@RestController
public class StudentController {
	
	//@Autowired
	StudentService studentService=new StudentService();
	StudentMarks sm=new StudentMarks();
	
	@RequestMapping(value = "/register", method = RequestMethod.POST,headers = "Accept=application/json")
	public ModelAndView registerStudent(ModelMap model,@ModelAttribute("student") Student student,HttpServletRequest request) {
		
		System.out.println("in controller");
	
		
		
		studentService.registerStudent(student);
		
		return new ModelAndView("home");
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST,headers = "Accept=application/json")
	public ModelAndView loginStudent(ModelMap model,HttpServletRequest request) {
		
		System.out.println("in controller");
		String un=request.getParameter("s_email");
		String pw=request.getParameter("s_pass");
		
		Student st=studentService.aunthenticate(un, pw);
		if(st!=null){
			StudentMarks list=studentService.getMarks(st.getS_id());
			System.out.println("in cont list:"+list);
		model.addAttribute("st", st);
			HttpSession se=request.getSession();
			
			se.setAttribute("num", st);
			se.setAttribute("list",list);
		return new ModelAndView("home");
		
		}
		if(st==null)
		{
			model.addAttribute("msg", "username or password is wrong");
			return new ModelAndView("login");
		}
		return new ModelAndView("hom");
		
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET,headers = "Accept=application/json")
	public ModelAndView logout(ModelMap model,@ModelAttribute("student") Student st,HttpServletRequest request) {
		
		st=null;
	
		return new ModelAndView("login");
	}
	
	
	@RequestMapping(value = "/marks", method = RequestMethod.POST,headers = "Accept=application/json")
	public ModelAndView studentMarks(ModelMap model,HttpServletRequest request) {
		
		int id=Integer.parseInt(request.getParameter("st_id"));
		System.out.println(id);
		String sem1=request.getParameter("sem1");
		String sem2=request.getParameter("sem2");
		String sem3=request.getParameter("sem3");
		String sem4=request.getParameter("sem4");
		String sem5=request.getParameter("sem5");
		String sem6=request.getParameter("sem6");
		String sem7=request.getParameter("sem7");
		String sem8=request.getParameter("sem8");
		
		 sm=studentService.saveMarks(id,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8);
	
		HttpSession se=request.getSession();
		se.setAttribute("marks", sm);
		
		return new ModelAndView("home");
		
	}

}
