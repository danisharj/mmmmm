package com.cybage.student.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cybage.student.config.HibernateSessionManager;
import com.cybage.student.model.Password;
import com.cybage.student.model.Student;
import com.cybage.student.model.StudentMarks;

@Repository
@Component
public class StudentDao {
	//@Autowired
	StudentMarks studentMarks=new StudentMarks();
	Student st=null;
	StudentMarks sm=null;
	Session session = HibernateSessionManager.getSessionFactory().openSession();
	
	public void save(Student student){
		
		
		 
		 session.beginTransaction();
		 session.save(student);
		 session.getTransaction().commit();
		 session.close();
	}
	
	public Student checkauthentic(String un,String pw){
		
		Query query = session.createQuery("from Student");
		
		List<Student> list = query.list();
		
		for (Student st : list) {
		    if(un.equals(st.getS_email())&&pw.equals(st.getS_pass())){
		    	System.out.println("matched");
		    	this.st=st;
		    	break;
		    	
		    }
		    else
		    {
		    	st=null;
		    	System.out.println("not matched");
		    	System.out.println(st);
		    	
		    }
		}
		//System.out.println(k);
		return st;
		
	}
	
	public StudentMarks saveMarks( int id,String sem1,String sem2,String sem3,String sem4,String sem5,String sem6,String sem7,String sem8)
	{
		studentMarks.setSt_id(id);
		studentMarks.setSem1(sem1);
		studentMarks.setSem2(sem2);
		studentMarks.setSem3(sem3);
		studentMarks.setSem4(sem4);
		studentMarks.setSem5(sem5);
		studentMarks.setSem6(sem6);
		studentMarks.setSem7(sem7);
		studentMarks.setSem8(sem8);
		
		session.beginTransaction();
		session.save(studentMarks);
		session.getTransaction().commit();
		session.close();
		
		return studentMarks;

		
		
	}
	public StudentMarks getMarks(int id){
		
		Query query = session.createQuery("from StudentMarks sm where sm.st_id=?");
		query.setParameter(0,id);
		List<StudentMarks> list=query.list();
		
		System.out.println(list);
		for (StudentMarks sm : list) {
			this.sm=sm;
		}
		
		return  sm;
		
	}

}
